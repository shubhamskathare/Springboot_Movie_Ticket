package com.moviebookingspring.moviebooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.moviebookingspring.moviebooking.entity.Inox;

public interface InoxRepo extends JpaRepository<Inox, Long> {

}
