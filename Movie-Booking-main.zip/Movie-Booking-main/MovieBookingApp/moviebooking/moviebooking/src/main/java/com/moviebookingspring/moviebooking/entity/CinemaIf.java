package com.moviebookingspring.moviebooking.entity;

public interface CinemaIf {
	

}
